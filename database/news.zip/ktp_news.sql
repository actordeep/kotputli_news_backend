-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 26, 2023 at 11:14 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ktp_news`
--

-- --------------------------------------------------------

--
-- Table structure for table `ads`
--

CREATE TABLE `ads` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ads` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ads`
--

INSERT INTO `ads` (`id`, `link`, `ads`, `type`, `created_at`, `updated_at`) VALUES
(1, 'www.youtube.com/c/DesiKaDum', 'image/brandad/63c91adfe2521.png', 2, NULL, NULL),
(2, 'www.youtube.com/c/DesiKaDum', 'image/brandad/63c91af40bab3.png', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_bg` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `soft_delete` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_en`, `category_bg`, `soft_delete`, `created_at`, `updated_at`) VALUES
(1, 'Education', 'शिक्षा', '0', NULL, NULL),
(2, 'Politics', 'राजनीति', '0', NULL, NULL),
(3, 'Business', 'व्यवसाय', '0', NULL, NULL),
(4, 'Entertainment', 'मनोरंजन', '0', NULL, NULL),
(5, 'General News', 'सामान्य समाचार', '0', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `districts`
--

CREATE TABLE `districts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `district_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `district_bg` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `districts`
--

INSERT INTO `districts` (`id`, `district_en`, `district_bg`, `created_at`, `updated_at`) VALUES
(1, 'Jaipur', 'जयपुर', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `livetvs`
--

CREATE TABLE `livetvs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `embed_code` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `livetvs`
--

INSERT INTO `livetvs` (`id`, `embed_code`, `status`, `created_at`, `updated_at`) VALUES
(1, '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/XxwlVZn--JQ\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen></iframe>', 1, '2023-01-19 09:33:20', '2023-01-19 09:33:20');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2014_10_12_200000_add_two_factor_columns_to_users_table', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(6, '2021_04_20_164633_create_sessions_table', 1),
(7, '2021_04_22_152715_create_categories_table', 1),
(8, '2021_04_22_152841_create_subcategories_table', 1),
(9, '2021_04_25_114837_create_districts_table', 1),
(10, '2021_04_25_115006_create_subdistricts_table', 1),
(11, '2021_04_26_180219_create_posts_table', 1),
(12, '2021_05_01_143157_create_socials_table', 1),
(13, '2021_05_01_151542_create_seos_table', 1),
(14, '2021_05_02_170848_create_livetvs_table', 1),
(15, '2021_05_02_185044_create_notices_table', 1),
(16, '2021_05_02_191744_create_websites_table', 1),
(17, '2021_05_03_072604_create_photos_table', 1),
(18, '2021_05_03_085253_create_videos_table', 1),
(19, '2021_05_10_090612_create_ads_table', 1),
(20, '2021_05_31_162211_create_websitesettings_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `notices`
--

CREATE TABLE `notices` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `notice` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notices`
--

INSERT INTO `notices` (`id`, `notice`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Kotputli City Daily Live News ..', 1, '2023-01-19 09:35:46', '2023-01-19 09:35:46');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `photos`
--

CREATE TABLE `photos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `photos`
--

INSERT INTO `photos` (`id`, `photo`, `title`, `type`, `created_at`, `updated_at`) VALUES
(1, 'image/photogallery/63c9191c9f5f1.png', 'Movies', '0', NULL, NULL),
(2, 'image/photogallery/63c9233bc3387.png', 'Avatar Movie', '1', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` int(11) NOT NULL,
  `subcategory_id` int(11) DEFAULT NULL,
  `district_id` int(11) NOT NULL,
  `subdistrict_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_bg` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `details_en` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details_bg` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tags_en` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tags_bg` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `headline` int(11) DEFAULT NULL,
  `first_section` int(11) DEFAULT NULL,
  `first_section_thumbnail` int(11) DEFAULT NULL,
  `bigthumbnail` int(11) DEFAULT NULL,
  `post_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `post_month` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `category_id`, `subcategory_id`, `district_id`, `subdistrict_id`, `user_id`, `title_en`, `title_bg`, `slug`, `image`, `details_en`, `details_bg`, `tags_en`, `tags_bg`, `headline`, `first_section`, `first_section_thumbnail`, `bigthumbnail`, `post_date`, `post_month`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 1, 1, 1, 'Children taking private tuition increased in the country, maximum in Bihar-Bengal: Report', 'देश में बढ़े प्राइवेट ट्यूशन लेने वाले बच्‍चे, बिहार-बंगाल में सबसे ज्‍यादा: रिपोर्ट', 'Children-taking-private-tuition-increased-in-the-country,-maximum-in-Bihar-Bengal:-Report', 'image/postimg/63c90be3ce3ae.jpg', '<div>After giving bonus shares twice in 2022 and declaring stock split in 1:2 ratio in the same year, Easy Trip Planners Ltd is going to consider buyouts soon. the company has informed Indian bourses that board of directors of the company are going to consider and approve proposal for acquisition in its next meeting scheduled on 24th January 2023.</div><div><br></div><div>Easy Trip Planners Ltd informed about the acquisition proposal citing, \"Pursuant to Regulation 29 other applicable Regulations, if any, of the SEBI (Listing Obligations and Disclosure Requirements) Regulations, 2015, we hereby intimate that a meeting of the Board of Directors of the Company is scheduled to be held on Tuesday, January 24, 2023, at 10.00 A.M. through video conferencing for considering the proposal of Acquisition.\"</div><div><br></div><div>As per the information available on BSE website, Easy Trip Planners Ltd has issued bonus shares twice in 2022. It traded ex-bonus stock in February 2022 for issuance of bonus shares in 1:1 ratio. This means the company issued one bonus share for each share held by the eligible shareholders of the company. similarly, Easy Trip Planners Ltd traded ex-bonus stocks in November 2022 for issuance of bonus shares in 3:1 ratio, which means the company has issued three bonus shares for each share held by the eligible shareholders of the company.</div><div><br></div><div>Click here for latest stock market news</div><div><br></div><div>Apart from these bonus shares, the company has declared stock-split as well. In November 2022, Easy Trip Planners Ltd traded ex-split as the company had declared stock subdivision in 1:2 ratio. This means, after stock subdivision, one\'s shareholding in the company doubled after the stock sub-division as one share of the company with a face value of ₹2 changed to Re 1 per equity share after the stock split.</div>', '<div>2022 में दो बार बोनस शेयर देने और उसी साल 1:2 के अनुपात में स्टॉक स्प्लिट घोषित करने के बाद, ईज़ी ट्रिप प्लानर्स लिमिटेड जल्द ही बायआउट्स पर विचार करने जा रहा है। कंपनी ने भारतीय बाजारों को सूचित किया है कि कंपनी के निदेशक मंडल 24 जनवरी 2023 को होने वाली अपनी अगली बैठक में अधिग्रहण के प्रस्ताव पर विचार और अनुमोदन करने जा रहे हैं।</div><div><br></div><div>ईज़ी ट्रिप प्लानर्स लिमिटेड ने अधिग्रहण प्रस्ताव के बारे में सूचित करते हुए कहा, \"सेबी (सूचीकरण बाध्यताएँ और प्रकटीकरण आवश्यकताएँ) विनियम, 2015 के विनियम 29 अन्य लागू विनियमों, यदि कोई हो, के अनुसार, हम इसके द्वारा सूचित करते हैं कि कंपनी के निदेशक मंडल की बैठक हो रही है। कंपनी अधिग्रहण के प्रस्ताव पर विचार करने के लिए वीडियो कॉन्फ्रेंसिंग के माध्यम से मंगलवार, 24 जनवरी, 2023 को सुबह 10.00 बजे आयोजित होने वाली है।\"</div><div><br></div><div>बीएसई की वेबसाइट पर उपलब्ध जानकारी के अनुसार, ईज़ी ट्रिप प्लानर्स लिमिटेड ने 2022 में दो बार बोनस शेयर जारी किए हैं। इसने 1:1 के अनुपात में बोनस शेयर जारी करने के लिए फरवरी 2022 में एक्स-बोनस स्टॉक का कारोबार किया। इसका मतलब है कि कंपनी ने कंपनी के पात्र शेयरधारकों द्वारा रखे गए प्रत्येक शेयर के लिए एक बोनस शेयर जारी किया। इसी तरह, ईज़ी ट्रिप प्लानर्स लिमिटेड ने 3:1 अनुपात में बोनस शेयर जारी करने के लिए नवंबर 2022 में एक्स-बोनस शेयरों का कारोबार किया, जिसका अर्थ है कि कंपनी ने कंपनी के पात्र शेयरधारकों द्वारा रखे गए प्रत्येक शेयर के लिए तीन बोनस शेयर जारी किए हैं।</div><div><br></div><div>शेयर बाजार की ताजा खबरों के लिए यहां क्लिक करें</div><div><br></div><div>इन बोनस शेयरों के अलावा कंपनी ने स्टॉक-स्प्लिट भी घोषित किया है। नवंबर 2022 में, ईज़ी ट्रिप प्लानर्स लिमिटेड ने एक्स-स्प्लिट का कारोबार किया क्योंकि कंपनी ने 1:2 अनुपात में स्टॉक उपखंड घोषित किया था। इसका मतलब है कि स्टॉक सब-डिवीजन के बाद, स्टॉक सब-डिवीजन के बाद कंपनी में किसी की शेयरहोल्डिंग दोगुनी हो गई, क्योंकि स्टॉक स्प्लिट के बाद ₹2 की फेस वैल्यू वाली कंपनी का एक शेयर बदलकर 1 रुपए प्रति इक्विटी शेयर हो गया।</div>', 'education,news,live,kotputli', 'शिक्षा, समाचार, लाइव, कोटपूतली', 1, 1, 1, 1, '19-01-2023', 'January', NULL, NULL),
(2, 2, 2, 1, 1, 1, 'Opinion | Pandemic accelerates growth in ayurvedic food, nutrition market', 'राय | महामारी आयुर्वेदिक भोजन, पोषण बाजार में विकास को गति देती है', 'Opinion-|-Pandemic-accelerates-growth-in-ayurvedic-food,-nutrition-market', 'image/postimg/63c90ca5dc2d1.png', '<p>It’s raining ayurvedic products. From big fast-moving consumer goods firms to young startups, everyone’s lining up ayurveda-based nutrition and wellness foods, riding on a spike in demand for traditional brews and blends in a world suffering its worst health crisis.</p><p><br></p><p>On the one hand, Dabur Ltd, already known for its ayurvedic and herbal products, is witnessing a huge surge in demand for its flagship immunity booster Dabur Chyawanprash and Dabur Honey. On the other, startups are looking to scale up their businesses to take advantage of the growing clamour for ayurvedic preventive healthcare products. Dabur has already launched a slew of immunity boosters such as Tulsi Drops, Giloy-Neem-Tulsi juice and an immunity kit. More innovations are in the pipeline in view of the shift in consumer preference.</p><p><br></p><p>But it is really startups that are most upbeat about the opportunity, as they quickly fill in the need gaps. Ameve Sharma, co-founder, Kapiva Ayurveda, and scion of the Baidyanath group, which specializes in ayurvedic medicines, admits that covid-19 has accelerated consumer awareness and consumer demand. But Kapiva, he said, was growing even before the pandemic.</p><p><br></p><p>For a company that started out as a retail model to create a chain of ayurveda clinics, Sharma quickly pivoted to being what he calls a “pure-play FMCG business\". “We expect to touch ₹100 crore turnover next year,\" he said, adding that there has been a rise in demand for his products in the past four months. Kapiva offers a range of herbal juices, powders and candies, gourmet honey and nutritional shakes. On the cards is a multigrain Kapiva breakfast, details of which Sharma is reluctant to share.</p><p><br></p><p>“Ayurveda is more preventive than curative. It is a lifestyle solution. We wanted to offer a modern take on ayurveda that resonates with the consumers,\" Sharma said.</p><p><br></p><p>Initially thought to be a metro-centric brand with its slightly premium pricing, online demand for Kapiva now comes from tier-2 and tier-3 cities. “In the last five years, customers have become proactive about health. They worry even about things like quality of sleep. With longer working hours, increased pollution and decline in the quality of food, they need to build immunity,\" Sharma said.</p><p><br></p><p>V.S. Kannan Sitaram, venture partner, Fireside Ventures, which has invested in Kapiva, said there’s a definite consumer traction for foods and supplements that are natural or ayurveda-based. “In India, health and wellness was a building trend. It’s now grabbing even more attention,\" Sitaram said, adding that organic food companies will also do well.</p><p><br></p><p>At Delhi-based Upakarma Ayurveda, co-founder Vishal Kaushik is also dealing with a surge in demand for its products, especially Ashwagandha, which helps the body cope with stress. The two-year-old brand is available at around 10,000 stores across 10 states and offers almond oil, shilajit resin and premium saffron. In the pipeline is Ayushkwath, a kadha (home remedy made from kitchen spices and herbs for cough and cold) recommended by the Ayush ministry to build immunity against covid.</p><p><br></p><p>On popular demand, the company is also getting into chyawanprash, herbal juices like aloe vera, giloy and amla. For consumers who cannot afford the bigger juice packs, Upakarma is launching immunity building drops from ginger, tulsi, amla and giloy. Kaushik said the company has been growing at 100% a year and expects to maintain the pace.</p><p><br></p><p>Surprisingly, figures on the size of the Indian market for ayurvedic products are hard to come by. Kaushik, however, estimates the international market, which is also turning to ayurveda wellness products, at $4.5 billion. The Indian market is growing at 30% a year, he said. With covid taking its toll, consumer demand for ayurvedic supplements has shot up and is likely to attract more startups to the space. Kaushik said all his vendors and suppliers are reporting a surge in queries and demand for raw material. The supply chain may see some shortages if demand spikes further. He also expects more private cultivators jumping into herbal plantations to meet this growing demand.</p><p><br></p><p>Shuchi Bansal is Mint’s media, marketing and advertising editor. Ordinary Post will look at pressing issues related to all three. Or just fun stuff.</p>', '<p>आयुर्वेदिक उत्पादों की बारिश हो रही है। बड़ी तेजी से आगे बढ़ने वाली उपभोक्ता वस्तुओं की फर्मों से लेकर युवा स्टार्टअप्स तक, हर कोई आयुर्वेद-आधारित पोषण और कल्याणकारी खाद्य पदार्थों को तैयार कर रहा है, पारंपरिक ब्रूज़ की मांग में तेजी से सवारी कर रहा है और दुनिया में सबसे खराब स्वास्थ्य संकट का सामना कर रहा है।</p><p><br></p><p>एक ओर, डाबर लिमिटेड, जो पहले से ही अपने आयुर्वेदिक और हर्बल उत्पादों के लिए जाना जाता है, अपने प्रमुख प्रतिरक्षा बूस्टर डाबर च्यवनप्राश और डाबर हनी की मांग में भारी उछाल देख रहा है। दूसरी ओर, आयुर्वेदिक निवारक स्वास्थ्य देखभाल उत्पादों के लिए बढ़ती मांग का लाभ उठाने के लिए स्टार्टअप अपने व्यवसायों को बढ़ाने की सोच रहे हैं। डाबर ने पहले ही तुलसी ड्रॉप्स, गिलोय-नीम-तुलसी जूस और एक इम्युनिटी किट जैसे कई इम्युनिटी बूस्टर लॉन्च किए हैं। उपभोक्ता वरीयता में बदलाव को देखते हुए और अधिक नवाचार पाइपलाइन में हैं।</p><p><br></p><p>लेकिन यह वास्तव में स्टार्टअप हैं जो अवसर के बारे में सबसे अधिक उत्साहित हैं, क्योंकि वे जल्दी से जरूरत के अंतराल को भर देते हैं। कपिवा आयुर्वेद के सह-संस्थापक और आयुर्वेदिक दवाओं में विशेषज्ञता रखने वाले बैद्यनाथ समूह के वंशज अमेवे शर्मा मानते हैं कि कोविड-19 ने उपभोक्ता जागरूकता और उपभोक्ता मांग में तेजी लाई है। लेकिन कपिवा ने कहा, महामारी से पहले भी बढ़ रहा था।</p><p><br></p><p>आयुर्वेद क्लीनिकों की एक श्रृंखला बनाने के लिए एक खुदरा मॉडल के रूप में शुरू हुई एक कंपनी के लिए, शर्मा ने जल्दी से \"प्योर-प्ले एफएमसीजी व्यवसाय\" कहा। \"हम अगले साल ₹100 करोड़ के कारोबार को छूने की उम्मीद करते हैं,\" उन्होंने कहा। , यह कहते हुए कि पिछले चार महीनों में उनके उत्पादों की मांग में वृद्धि हुई है। कपिवा कई प्रकार के हर्बल जूस, पाउडर और कैंडीज, रुचिकर शहद और पौष्टिक शेक प्रदान करता है। कार्डों पर एक मल्टीग्रेन कपिवा नाश्ता है, जिसके बारे में शर्मा साझा करने के लिए अनिच्छुक हैं।</p><p><br></p><p>“आयुर्वेद उपचारात्मक से अधिक निवारक है। यह एक जीवनशैली समाधान है। हम आयुर्वेद को एक आधुनिक रूप देना चाहते थे जो उपभोक्ताओं को पसंद आए।\" शर्मा ने कहा।</p><p><br></p><p>शुरू में अपने थोड़े प्रीमियम मूल्य के साथ एक मेट्रो-केंद्रित ब्रांड माना जाता था, कपिवा की ऑनलाइन मांग अब टियर-2 और टियर-3 शहरों से आती है। “पिछले पांच वर्षों में, ग्राहक स्वास्थ्य के बारे में सक्रिय हो गए हैं। वे नींद की गुणवत्ता जैसी चीजों के बारे में भी चिंता करते हैं। लंबे समय तक काम करने, बढ़ते प्रदूषण और भोजन की गुणवत्ता में गिरावट के साथ, उन्हें प्रतिरक्षा बनाने की जरूरत है,\" शर्मा ने कहा।</p><p><br></p><p>वी.एस. कन्नन सीताराम, उद्यम भागीदार, फायरसाइड वेंचर्स, जिसने कपिवा में निवेश किया है, ने कहा कि प्राकृतिक या आयुर्वेद-आधारित खाद्य पदार्थों और पूरक के लिए एक निश्चित उपभोक्ता कर्षण है। “भारत में, स्वास्थ्य और कल्याण एक निर्माण प्रवृत्ति थी। यह अब और भी अधिक ध्यान आकर्षित कर रहा है,\" सीताराम ने कहा, जैविक खाद्य कंपनियां भी अच्छा प्रदर्शन करेंगी।</p><p><br></p><p>दिल्ली स्थित उपकर्मा आयुर्वेद में, सह-संस्थापक विशाल कौशिक भी अपने उत्पादों, विशेष रूप से अश्वगंधा की मांग में वृद्धि से निपट रहे हैं, जो शरीर को तनाव से निपटने में मदद करता है। दो साल पुराना ब्रांड 10 राज्यों में लगभग 10,000 स्टोर्स पर उपलब्ध है और बादाम का तेल, शिलाजीत राल और प्रीमियम केसर प्रदान करता है। आयुष मंत्रालय पाइपलाइन में है, एक कड़ा (खांसी और सर्दी के लिए रसोई के मसालों और जड़ी-बूटियों से बना घरेलू उपचार) जिसे आयुष मंत्रालय ने कोविड के खिलाफ प्रतिरोधक क्षमता बनाने के लिए सुझाया है।</p><p><br></p><p>लोगों की मांग पर कंपनी च्यवनप्राश, एलोवेरा, गिलोय और आंवला जैसे हर्बल जूस भी पेश कर रही है। जो उपभोक्ता बड़े जूस पैक नहीं खरीद सकते, उनके लिए उपकर्मा अदरक, तुलसी, आंवला और गिलोय से प्रतिरोधक क्षमता बढ़ाने वाली बूंदें पेश कर रहा है। कौशिक ने कहा कि कंपनी सालाना 100 फीसदी की दर से बढ़ रही है और उम्मीद है कि यह रफ्तार बरकरार रहेगी।</p><p><br></p><p>आश्चर्यजनक रूप से, आयुर्वेदिक उत्पादों के लिए भारतीय बाजार के आकार के आंकड़े प्राप्त करना मुश्किल है। कौशिक, हालांकि, अंतरराष्ट्रीय बाजार का अनुमान लगाते हैं, जो कि आयुर्वेद कल्याण उत्पादों की ओर भी मुड़ रहा है, $ 4.5 बिलियन। उन्होंने कहा कि भारतीय बाजार सालाना 30 फीसदी की दर से बढ़ रहा है। कोविड का कहर बढ़ने के साथ, आयुर्वेदिक सप्लीमेंट्स के लिए उपभोक्ताओं की मांग बढ़ी है और इस क्षेत्र में अधिक स्टार्टअप्स को आकर्षित करने की संभावना है। कौशिक ने कहा कि उनके सभी विक्रेता और आपूर्तिकर्ता कच्चे माल की मांग और पूछताछ में वृद्धि की सूचना दे रहे हैं। अगर मांग और बढ़ती है तो आपूर्ति श्रृंखला में कुछ कमी देखने को मिल सकती है। उन्हें उम्मीद है कि इस बढ़ती मांग को पूरा करने के लिए और अधिक निजी किसान हर्बल बागानों में कूदेंगे।</p><p><br></p><p>शुचि बंसल मिंट की मीडिया, मार्केटिंग और विज्ञापन संपादक हैं। साधारण पोस्ट तीनों से संबंधित महत्वपूर्ण मुद्दों पर ध्यान देगी। या सिर्फ मज़ेदार चीज़ें।</p>', 'opinion,pandemic,growth,', 'राय, महामारी, विकास,', 1, 1, NULL, 1, '19-01-2023', 'January', NULL, NULL),
(3, 3, 3, 1, 1, 1, 'Perennial Partners Joins Shareholder Register of Complexica, Bringing Total to $22 million Invested During Past 18 months', 'बारहमासी भागीदार कॉम्प्लेक्सिका के शेयरधारक रजिस्टर में शामिल हो गए, पिछले 18 महीनों के दौरान कुल $22 मिलियन का निवेश किया', 'Perennial-Partners-Joins-Shareholder-Register-of-Complexica,-Bringing-Total-to-$22-million-Invested-During-Past-18-months', 'image/postimg/63c9158e1d253.jpg', '<div>Complexica Pty Ltd, a leading provider of Artificial Intelligence software for optimising sales, marketing, and supply chain activities, announced today that Perennial Partners invested $3 million into the company, bringing the total investment by outside investors to $22 million during the past 18 months. They will join existing institutional investors on the shareholder register, which include well-known fund manager Microequities Asset Management (ASX: MAM), ports and logistics operator Flinders Ports Holdings, and ASX-listed investment bank and fund manager MA Financial (ASX: MAF).</div><div><br></div><div>“Complexica is a hugely exciting business for Perennial Partners. We believe that Matt and his founding team are outstanding, and highly backable, having built and exited two successful enterprise AI platform businesses over the last 20 years,\" said James McQueen, Senior Investment &amp; Legal Principal at Perennial Partners. \"With Complexica, the team have built a highly sophisticated, AI-driven decision making platform that captures and delivers enormous value to a large and growing number of quality blue chip customers across a range of industries. Complexica has a market leading position in Australia and is well positioned to scale up significantly both within Australia and globally. We are thrilled to be joining the register and look forward to supporting Matt and the team as they grow Complexica going forward.”</div><div><br></div><div>Perennial Partners is an Australian fund manager with over A$8 billion on behalf of institutional and retail clients. Perennial focusses on delivering outstanding investment opportunities and outcomes for its clients in segments of the market where active management adds meaningful value. Within Perennial, the Perennial Private team actively manages over A$700m across a series of private company and pre-IPO funds. Perennial offers wholesale investors the opportunity to invest alongside a highly experienced team with deep capabilities, networks and experience in both private and public markets. The Perennial Private Investments strategy focusses on generating superior returns from an actively-managed diverse portfolio of growth equity, pre-IPO and IPO opportunities. Perennial Private Ventures is a dedicated private growth fund targeting businesses with outstanding founder teams, strong high growth business models, and demonstrated commercial traction that are well positioned to capture valuation upside as they enter or accelerate through the grow and scale up phase of the company lifecycle.&nbsp;</div><div><br></div><div>Complexica is a leading provider of Artificial Intelligence software applications that can optimise sales, marketing, and supply chain decisions, particularly for organisations characterised by a large SKU range and long tail of customers. The company was founded upon the research of several world-renown computer scientists, and has commercialised a modularised software platform called Decision Cloud® that empowers staff across multiple business functions to make better decisions. Decision Cloud® is powered by Complexica\'s Artificial Intelligence engine Larry, the Digital Analyst®, which was named the 2018 Australian Innovation of Year.</div>', '<p>बिक्री, विपणन और आपूर्ति श्रृंखला गतिविधियों को अनुकूलित करने के लिए आर्टिफिशियल इंटेलिजेंस सॉफ्टवेयर के एक अग्रणी प्रदाता, कॉम्प्लेक्सिका पीटीई लिमिटेड ने आज घोषणा की कि पेरेनियल पार्टनर्स ने कंपनी में $3 मिलियन का निवेश किया है, जिससे पिछले 18 महीनों के दौरान बाहरी निवेशकों द्वारा कुल निवेश $22 मिलियन हो गया है। वे शेयरधारक रजिस्टर पर मौजूदा संस्थागत निवेशकों में शामिल होंगे, जिसमें जाने-माने फंड मैनेजर माइक्रोइक्विटीज एसेट मैनेजमेंट (ASX: MAM), पोर्ट्स और लॉजिस्टिक्स ऑपरेटर फ्लिंडर्स पोर्ट्स होल्डिंग्स, और ASX- सूचीबद्ध निवेश बैंक और फंड मैनेजर MA Financial (ASX: MAF) शामिल हैं। ).</p><p><br></p><p>\"कॉम्प्लेक्सिका बारहमासी भागीदारों के लिए एक बेहद रोमांचक व्यवसाय है। हम मानते हैं कि मैट और उनकी संस्थापक टीम पिछले 20 वर्षों में दो सफल उद्यम एआई प्लेटफॉर्म व्यवसायों का निर्माण और निकास करने के लिए उत्कृष्ट, और अत्यधिक समर्थन योग्य हैं,\" पेरेनियल पार्टनर्स में सीनियर इनवेस्टमेंट एंड लीगल प्रिंसिपल जेम्स मैकक्वीन ने कहा। \"कॉम्प्लेक्सिका के साथ, द टीम ने एक अत्यधिक परिष्कृत, एआई-संचालित निर्णय लेने वाला प्लेटफॉर्म बनाया है जो उद्योगों की एक श्रृंखला में गुणवत्ता वाले ब्लू चिप ग्राहकों की बड़ी और बढ़ती संख्या को पकड़ता है और वितरित करता है। कॉम्प्लेक्सिका की ऑस्ट्रेलिया में बाजार में अग्रणी स्थिति है और यह ऑस्ट्रेलिया और वैश्विक स्तर पर महत्वपूर्ण रूप से विस्तार करने के लिए अच्छी स्थिति में है। हम रजिस्टर में शामिल होने के लिए रोमांचित हैं और मैट और टीम का समर्थन करने के लिए तत्पर हैं क्योंकि वे कॉम्प्लेक्सिका को आगे बढ़ा रहे हैं।</p><p><br></p><p>पेरेनियल पार्टनर्स संस्थागत और खुदरा ग्राहकों की ओर से $8 बिलियन से अधिक के साथ एक ऑस्ट्रेलियाई फंड मैनेजर है। बारहमासी बाजार के उन क्षेत्रों में अपने ग्राहकों के लिए उत्कृष्ट निवेश के अवसर और परिणाम देने पर ध्यान केंद्रित करता है जहां सक्रिय प्रबंधन सार्थक मूल्य जोड़ता है। बारहमासी के भीतर, बारहमासी निजी टीम सक्रिय रूप से निजी कंपनी और प्री-आईपीओ फंडों की एक श्रृंखला में ए $ 700 मिलियन से अधिक का प्रबंधन करती है। बारहमासी थोक निवेशकों को निजी और सार्वजनिक दोनों बाजारों में गहरी क्षमताओं, नेटवर्क और अनुभव के साथ एक उच्च अनुभवी टीम के साथ निवेश करने का अवसर प्रदान करता है। बारहमासी निजी निवेश रणनीति ग्रोथ इक्विटी, प्री-आईपीओ और आईपीओ अवसरों के एक सक्रिय रूप से प्रबंधित विविध पोर्टफोलियो से बेहतर रिटर्न उत्पन्न करने पर ध्यान केंद्रित करती है। पेरेनियल प्राइवेट वेंचर्स एक समर्पित प्राइवेट ग्रोथ फंड है, जो बकाया फाउंडर टीमों, मजबूत हाई ग्रोथ बिजनेस मॉडल और प्रदर्शित कमर्शियल ट्रैक्शन के साथ बिजनेस को लक्षित करता है, जो कंपनी लाइफसाइकिल के ग्रोथ और स्केल अप चरण के माध्यम से प्रवेश या तेजी के साथ वैल्यूएशन को पकड़ने के लिए अच्छी तरह से तैनात हैं। .</p><p><br></p><p>कॉम्प्लेक्सिका आर्टिफिशियल इंटेलिजेंस सॉफ्टवेयर अनुप्रयोगों का एक अग्रणी प्रदाता है जो बिक्री, विपणन और आपूर्ति श्रृंखला के निर्णयों को अनुकूलित कर सकता है, विशेष रूप से बड़ी SKU रेंज और ग्राहकों की लंबी पूंछ वाले संगठनों के लिए। कंपनी की स्थापना कई विश्व-प्रसिद्ध कंप्यूटर वैज्ञानिकों के शोध पर की गई थी, और इसने निर्णय क्लाउड® नामक एक मॉड्यूलर सॉफ़्टवेयर प्लेटफ़ॉर्म का व्यावसायीकरण किया है जो बेहतर निर्णय लेने के लिए कई व्यावसायिक कार्यों में कर्मचारियों को सशक्त बनाता है। डिसीजन क्लाउड® कॉम्प्लेक्सिका के आर्टिफिशियल इंटेलिजेंस इंजन लैरी, डिजिटल एनालिस्ट® द्वारा संचालित है, जिसे 2018 ऑस्ट्रेलियन इनोवेशन ऑफ ईयर का नाम दिया गया था।</p>', 'perennial,partners,joins,register', 'बारहमासी, भागीदार, जुड़ता है, रजिस्टर करता है', 1, NULL, 1, 1, '19-01-2023', 'January', NULL, NULL),
(4, 4, 4, 1, 1, 1, 'Seventh annual Fleurieu Film Festival comes to McLaren Vale this February', 'इस फरवरी में सातवां वार्षिक फ्लेरीउ फिल्म फेस्टिवल मैकलेरन वेल में आता है', 'Seventh-annual-Fleurieu-Film-Festival-comes-to-McLaren-Vale-this-February', 'image/postimg/63c916b2a49bd.png', '<p>The Fleurieu Film Festival returns with a selection of 15 finalist short films played at the McLaren Vale and Fleurieu Coast Visitors Centre, supporting local filmmakers with prizes and exposure to a live audience.</p><p><br></p><p>&nbsp;</p><p><br></p><p>Securing a Community Events Grant from the City of Onkaparinga as well as film industry and business support from more than 20 sponsors, the Fleurieu Film Festival is running its seventh film awards event, bringing 600-800 attendees a year to the Fleurieu Region.</p><p><br></p><p>&nbsp;</p><p><br></p><p>Carolyn Corkindale, Festival Director said that after COVID-19 lockdowns the festival\'s success was secured by the talented board members and creative team.</p><p><br></p><p>&nbsp;</p><p><br></p><p>\"Our film festival is backed by a strong group of successful and experienced creatives who inspire emerging filmmakers to enter the festival with increasingly excellent short films,\" Carolyn said. The Fleurieu Film Festival recently welcomed new board members Rick Davies (Producer, Living Not Beige Films - The Angels: Kickin\' Down the Door) and Kristen Hamill (City Producer, Adelaide 48 Hour Film Project).</p><p><br></p><p>&nbsp;</p><p><br></p><p>The festival has had many successful alumni in the past, including 2022 Best Director award winner Alice Yang who went on to not only secure a place as one of 12 participants chosen to attend the AFTRS National Talent Camp 2022 but also gained employment at SA production company Beyond Content (which was established by 2016 Best Film/Director award winner Stephen de Villiers). Carolyn and the creative team at the Fleurieu Film Festival are excited to see what the 2023 award winners achieve in the future.</p><p><br></p><p>&nbsp;</p><p><br></p><p>In 2023 the festival will feature mostly South Australian local films, many from young students who may have never had the chance to get their film shown in front of a large audience. Films this year will feature the theme GIFT, which can be \"interpreted widely, from the physical gifts we give to others to the metaphorical gifts of life and love.\" One of the films, All Is Well, is from 28 year old South Australian filmmaker Shuying Liu (Grace). Grace moved to South Australia from Yunnan, China when she was 15 and has used her experience of COVID-19 border closures to create a beautiful story told in Mandarin about a couple\'s experience trying to connect with family and friends during Lunar New Year.</p><p><br></p><p>&nbsp;</p><p><br></p><p>The Fleurieu Film Festival events are not only lauded for an entertaining selection of short films, but also \"music, food and wine in an open air setting against beautiful McLaren Vale vines and always topped with a special sunset,\" said Carolyn. The festival returns for the second year in a row to the picturesque lawns of the Visitors Centre on Saturday 4th February 2023. Tickets can be purchased via their website www.fleurieufilmfestival.com.au/tickets</p>', '<p>फ्लेरीयू फिल्म फेस्टिवल मैकलेरन वेल और फ्लेरीयू कोस्ट विज़िटर सेंटर में खेली गई 15 अंतिम लघु फिल्मों के चयन के साथ लौटता है, स्थानीय फिल्म निर्माताओं को पुरस्कार और लाइव दर्शकों के संपर्क में सहायता करता है।</p><p><br></p><p>&nbsp;</p><p><br></p><p>ऑनकापरिंगा शहर से एक सामुदायिक कार्यक्रम अनुदान के साथ-साथ फिल्म उद्योग और 20 से अधिक प्रायोजकों से व्यावसायिक सहायता प्राप्त करते हुए, फ्लेरीउ फिल्म फेस्टिवल अपना सातवां फिल्म पुरस्कार समारोह चला रहा है, जिसमें फ्लेरियू क्षेत्र में एक वर्ष में 600-800 उपस्थित लोग आते हैं।</p><p><br></p><p>&nbsp;</p><p><br></p><p>कैरोलिन कॉर्किन्डेल, फेस्टिवल डायरेक्टर ने कहा कि COVID-19 लॉकडाउन के बाद फेस्टिवल की सफलता प्रतिभाशाली बोर्ड सदस्यों और रचनात्मक टीम द्वारा सुरक्षित की गई।</p><p><br></p><p>&nbsp;</p><p><br></p><p>कैरोलिन ने कहा, \"हमारा फिल्म फेस्टिवल सफल और अनुभवी क्रिएटिव के एक मजबूत समूह द्वारा समर्थित है, जो उभरते हुए फिल्म निर्माताओं को उत्कृष्ट लघु फिल्मों के साथ फेस्टिवल में प्रवेश करने के लिए प्रेरित करता है।\" द फ्लेरीउ फिल्म फेस्टिवल ने हाल ही में नए बोर्ड सदस्यों रिक डेविस (निर्माता, लिविंग नॉट बेज फिल्म्स - द एंजल्स: किकिन डाउन द डोर) और क्रिस्टन हैमिल (सिटी प्रोड्यूसर, एडिलेड 48 ऑवर फिल्म प्रोजेक्ट) का स्वागत किया।</p><p><br></p><p>&nbsp;</p><p><br></p><p>इस उत्सव में अतीत में कई सफल पूर्व छात्र रहे हैं, जिनमें 2022 के सर्वश्रेष्ठ निर्देशक पुरस्कार विजेता एलिस यांग शामिल हैं, जिन्होंने एएफटीआरएस नेशनल टैलेंट कैंप 2022 में भाग लेने के लिए चुने गए 12 प्रतिभागियों में से एक के रूप में न केवल एक स्थान सुरक्षित किया, बल्कि एसए प्रोडक्शन कंपनी में रोजगार भी प्राप्त किया। बियॉन्ड कंटेंट (जो 2016 के सर्वश्रेष्ठ फिल्म/निर्देशक पुरस्कार विजेता स्टीफन डी विलियर्स द्वारा स्थापित किया गया था)। फ्लेरीउ फिल्म फेस्टिवल में कैरोलिन और क्रिएटिव टीम यह देखने के लिए उत्साहित हैं कि 2023 के पुरस्कार विजेता भविष्य में क्या हासिल करेंगे।</p><p><br></p><p>&nbsp;</p><p><br></p><p>2023 में उत्सव में ज्यादातर दक्षिण ऑस्ट्रेलियाई स्थानीय फिल्में दिखाई जाएंगी, जिनमें से कई युवा छात्र होंगे जिन्हें अपनी फिल्म को बड़े दर्शकों के सामने दिखाने का मौका कभी नहीं मिला होगा। इस साल फिल्मों में GIFT थीम होगी, जिसकी \"व्यापक रूप से व्याख्या की जा सकती है, भौतिक उपहारों से जो हम दूसरों को जीवन और प्रेम के रूपक उपहार देते हैं।\" फिल्मों में से एक, ऑल इज वेल, 28 वर्षीय दक्षिण ऑस्ट्रेलियाई फिल्म निर्माता शुयिंग लियू (ग्रेस) की है। ग्रेस 15 साल की उम्र में युन्नान, चीन से दक्षिण ऑस्ट्रेलिया चली गईं और चंद्र नव वर्ष के दौरान परिवार और दोस्तों के साथ जुड़ने की कोशिश करने वाले एक जोड़े के अनुभव के बारे में मंदारिन में बताई गई एक सुंदर कहानी बनाने के लिए COVID-19 सीमा बंद होने के अपने अनुभव का उपयोग किया।</p><p><br></p><p>&nbsp;</p><p><br></p><p>कैरोलिन ने कहा, फ्लेरीउ फिल्म फेस्टिवल की घटनाओं की न केवल लघु फिल्मों के मनोरंजक चयन के लिए सराहना की जाती है, बल्कि \"सुंदर मैकलेरन वेल वाइन के खिलाफ खुली हवा में संगीत, भोजन और शराब और हमेशा एक विशेष सूर्यास्त के साथ सबसे ऊपर है\"। शनिवार 4 फरवरी 2023 को आगंतुक केंद्र के सुरम्य लॉन में लगातार दूसरे वर्ष यह उत्सव लौटता है। टिकट उनकी वेबसाइट www.fleurieufilmfestival.com.au/tickets के माध्यम से खरीदे जा सकते हैं।</p>', 'seventh,annual,film,festival', 'सातवां, वार्षिक, फिल्म, त्योहार', NULL, 1, 1, 1, '19-01-2023', 'January', NULL, NULL),
(5, 5, 5, 1, 1, 1, 'Zion Christian Mission Center Largest Graduation Yet', 'सिय्योन ईसाई मिशन केंद्र अभी तक का सबसे बड़ा स्नातक', 'Zion-Christian-Mission-Center-Largest-Graduation-Yet', 'image/postimg/63c917a62de37.png', '<p>The Zion Christian Mission Center, a Bible education institution of the Shincheonji Church of Jesus, held class of 113 graduation at Daegu Stadium, South Korea on the 20th November. A total of 106,186 people graduated on the day, making it the world\'s largest theological education institution.</p><p><br></p><p>The completion ceremony was prepared thoroughly to prevent safety issue as it is highly concerned recently. The Shincheonji Church of Jesus said, \"For preparing this event, safety is the first, second and third.”, \"We will create a cooperative network with local governments to check disinfection, safety, traffic, and order several times and operate a control room for monitoring the event with police, fire departments, Daegu-si, and Suseong-gu Office safety officials.\"</p><p><br></p><p>For safety reasons, the number of people participating in the completion ceremony in Korea will be limited to 80,000. About 300,000 people in total (Online or offline) will participate in the completion ceremony on YouTube live broadcasts in nine languages.</p><p><br></p><p>In addition, “the church itself allocated a total of 14,000 safety personnel to maintain order inside and outside the venue, and made participants enter and leave the event venue over four hours to prevent overcrowding.” he said. \"About 180 medical staff and four ambulances are also on standby in case of an accident.\" Emergency rescue training was conducted for all safety personnel, and all graduates also completed emergency rescue videos. \"We emphasize that this completion ceremony was especially safety-oriented,\" he explained.</p><p><br></p><p>The event consists of an opening ceremony and the completion ceremony. In the first part, starting with praise services, congratulatory speeches, congratulatory messages, representative prayers, and concluded with commemorative speeches of Chairman Man-Hee Lee. The second part will include a congratulatory performance, a congratulatory speech by Tan Young-jin, the head of the Zion Christian Mission Center, a certificate of completion, a tassel turning, award ceremony, testimony from graduates, and a special performance.</p><p><br></p><p>Among the class 113 graduates, a total of 522 pastors, including 37 in Korea and 485 overseas, will graduate from the program. This proportion of pastors has increased significantly compared to other years. In this background, it is closely related to the creation of an online class environment due to COVID-19. As an environment where students can take classes without being aware of others was created, the number of pastors and seminaries increased rapidly. The two representatives of the graduates who announced their acceptance speech on this day were also pastors.</p><p><br></p><p>The fact that pastors who joined the introductory, intermediate course including Revelation (Advanced), were able to participate in education online without being aware of other people during the COVID-19 pandemic is the background of the increase in the number of pastors.</p><p>&nbsp;</p><p><br></p><p>Heo Jung-wook, who shared the testimony as a representative of a Korean graduate at the completion ceremony, is a current pastor who has been pastor for a decade. After 20 years of ministry, he said, \"I only learned traditional theology in seminary, but I didn\'t know much about Revelation. Except for difficult words, he has taught only easy words to convey to the saints. I repent that I was a sinner who added and subtracted from the word of God,\" he said. \"I put down all my possessions and came forward to the truth.\" I learned true theology that leads me to heaven, not to study of mankind. \"I thank God for giving me a chance to live,\" he said.</p><p><br></p><p>D. Jackson, a representative of overseas graduates, is also an Indian pastor who changed the name of his seminary to the Hepto Zion Christian Mission Center after signing an MOU with Shincheonji. He also joined the online Bible class at the Shincheonji Church in October last year. Currently, 294 members of the church, including the pastor in charge of the two churches, have completed the entire course of the Zion Christian Mission Center and are listed as the class 113 graduates.</p><p><br></p><p>Meanwhile, the Shincheonji Church of Jesus focused on contributing to the revitalization of the local economy and coexisting with local residents by holding the first large-scale face-to-face event in Daegu since the COVID-19 pandemic. All possible consumption activities, such as transportation, accommodation, and meals for 100,000 people, were made in the region to help local residents.</p><p><br></p><p>After the Itaewon disaster, there were consideration to proceed with the event or postpone it, but rather than abandoning it, the win-win opportunity in consideration of the contract situation with local companies, it is decided to do the event focused on safety as much as possible based on the know-how of hosting large-scale domestic and foreign events.</p>', '<p>सिय्योन क्रिश्चियन मिशन सेंटर, जीसस के शिनचोनजी चर्च की एक बाइबिल शिक्षा संस्था, ने 20 नवंबर को डेगू स्टेडियम, दक्षिण कोरिया में 113 स्नातक की कक्षा आयोजित की। उस दिन कुल 106,186 लोगों ने स्नातक की उपाधि प्राप्त की, जिससे यह दुनिया का सबसे बड़ा धार्मिक शिक्षा संस्थान बन गया।</p><p><br></p><p>समापन समारोह सुरक्षा मुद्दे को रोकने के लिए पूरी तरह से तैयार किया गया था क्योंकि यह हाल ही में अत्यधिक चिंतित है। जीसस के शिनचोनजी चर्च ने कहा, \"इस आयोजन की तैयारी के लिए, सुरक्षा पहले, दूसरे और तीसरे स्थान पर है।\" पुलिस, अग्निशमन विभाग, डेगू-सी, और सुसेओंग-गु कार्यालय सुरक्षा अधिकारियों के साथ घटना की निगरानी के लिए कमरा।\"</p><p><br></p><p>सुरक्षा कारणों से कोरिया में पूर्णता समारोह में भाग लेने वाले लोगों की संख्या 80,000 तक सीमित रहेगी। नौ भाषाओं में YouTube लाइव प्रसारण पर समापन समारोह में कुल (ऑनलाइन या ऑफलाइन) लगभग 300,000 लोग भाग लेंगे।</p><p><br></p><p>इसके अलावा, \"चर्च ने स्वयं आयोजन स्थल के अंदर और बाहर व्यवस्था बनाए रखने के लिए कुल 14,000 सुरक्षा कर्मियों को आवंटित किया, और भीड़भाड़ को रोकने के लिए प्रतिभागियों को चार घंटे से अधिक समय तक कार्यक्रम स्थल में प्रवेश करने और छोड़ने के लिए कहा।\" उन्होंने कहा। दुर्घटना की स्थिति में लगभग 180 मेडिकल स्टाफ और चार एंबुलेंस भी स्टैंडबाय पर हैं। सभी सुरक्षा कर्मियों के लिए आपातकालीन बचाव प्रशिक्षण आयोजित किया गया और सभी स्नातकों ने आपातकालीन बचाव वीडियो भी पूरे किए। \"हम जोर देते हैं कि यह समापन समारोह विशेष रूप से सुरक्षा उन्मुख था,\" उन्होंने समझाया।</p><p><br></p><p>इस कार्यक्रम में एक उद्घाटन समारोह और समापन समारोह शामिल है। पहले भाग में, स्तुति सेवाओं, बधाई भाषणों, बधाई संदेशों, प्रतिनिधि प्रार्थनाओं के साथ शुरू हुआ और अध्यक्ष मैन-ही ली के स्मारक भाषणों के साथ समाप्त हुआ। दूसरे भाग में एक बधाई प्रदर्शन, ज़ायन क्रिश्चियन मिशन सेंटर के प्रमुख टैन यंग-जिन द्वारा एक बधाई भाषण, पूर्णता का प्रमाण पत्र, एक लटकन मोड़, पुरस्कार समारोह, स्नातकों की गवाही और एक विशेष प्रदर्शन शामिल होगा।</p><p><br></p><p>कक्षा 113 स्नातकों में, कोरिया में 37 और विदेशों में 485 सहित कुल 522 पादरी कार्यक्रम से स्नातक होंगे। अन्य वर्षों की तुलना में पादरियों के इस अनुपात में काफी वृद्धि हुई है। इस पृष्ठभूमि में, यह COVID-19 के कारण एक ऑनलाइन कक्षा के वातावरण के निर्माण से निकटता से संबंधित है। एक ऐसे वातावरण के रूप में जहां छात्र दूसरों को जाने बिना कक्षाएं ले सकते हैं, पास्टरों और मदरसों की संख्या में तेजी से वृद्धि हुई। इस दिन अपने स्वीकृति भाषण की घोषणा करने वाले स्नातकों के दो प्रतिनिधि भी पादरी थे।</p><p><br></p><p>तथ्य यह है कि जो पादरी प्रकाशितवाक्य (उन्नत) सहित प्रारंभिक, मध्यवर्ती पाठ्यक्रम में शामिल हुए, वे COVID-19 महामारी के दौरान अन्य लोगों को जाने बिना ऑनलाइन शिक्षा में भाग लेने में सक्षम थे, पादरी की संख्या में वृद्धि की पृष्ठभूमि है।</p><p>&nbsp;</p><p><br></p><p>हियो जुंग-वूक, जिन्होंने पूर्णता समारोह में एक कोरियाई स्नातक के प्रतिनिधि के रूप में गवाही साझा की, एक वर्तमान पादरी हैं जो एक दशक से पादरी हैं। 20 साल की सेवकाई के बाद, उन्होंने कहा, \"मैंने केवल मदरसा में पारंपरिक धर्मशास्त्र सीखा, लेकिन मुझे रहस्योद्घाटन के बारे में ज्यादा जानकारी नहीं थी। कठिन शब्दों को छोड़कर, उन्होंने संतों को संप्रेषित करने के लिए केवल आसान शब्दों को सिखाया है। मुझे पश्चाताप है कि मैं था। एक पापी जिसने परमेश्वर के वचन में जोड़ा और घटाया,\" उसने कहा। \"मैंने अपनी सारी संपत्ति नीचे रख दी और सच्चाई के लिए आगे आया।\" मैंने सच्चा धर्मशास्त्र सीखा जो मुझे स्वर्ग की ओर ले जाता है, मानव जाति का अध्ययन करने के लिए नहीं। उन्होंने कहा, \"मुझे जीने का मौका देने के लिए मैं भगवान का शुक्रिया अदा करता हूं।\"</p><p><br></p><p>डी. जैक्सन, विदेशी स्नातकों के एक प्रतिनिधि, एक भारतीय पादरी भी हैं, जिन्होंने शिनचोनजी के साथ एक समझौता ज्ञापन पर हस्ताक्षर करने के बाद अपने सेमिनरी का नाम हेप्टो ज़ियोन क्रिश्चियन मिशन सेंटर में बदल दिया। वह पिछले साल अक्टूबर में शिनचोनजी चर्च में ऑनलाइन बाइबल क्लास में भी शामिल हुए थे। वर्तमान में, दो चर्चों के प्रभारी पादरी सहित चर्च के 294 सदस्यों ने सिय्योन क्रिश्चियन मिशन सेंटर के पूरे पाठ्यक्रम को पूरा कर लिया है और कक्षा 113 स्नातकों के रूप में सूचीबद्ध हैं।</p><p><br></p><p>इस बीच, यीशु के शिनचोनजी चर्च ने COVID-19 महामारी के बाद से डेगू में पहली बार बड़े पैमाने पर आमने-सामने की घटना को आयोजित करके स्थानीय अर्थव्यवस्था के पुनरोद्धार में योगदान देने और स्थानीय निवासियों के साथ सह-अस्तित्व पर ध्यान केंद्रित किया। स्थानीय निवासियों की सहायता के लिए इस क्षेत्र में परिवहन, आवास और 100,000 लोगों के लिए भोजन जैसी सभी संभावित उपभोग गतिविधियों को बनाया गया था।</p><p><br></p><p>इटावन दुर्घटना के बाद, इस घटना को आगे बढ़ाने या इसे स्थगित करने पर विचार किया गया था, लेकिन स्थानीय कंपनियों के साथ अनुबंध की स्थिति को ध्यान में रखते हुए, इसे छोड़ने के बजाय, जीत-जीत के अवसर को ध्यान में रखते हुए, सुरक्षा पर ध्यान केंद्रित करने का निर्णय लिया गया। बड़े पैमाने पर घरेलू और विदेशी आयोजनों की मेजबानी की जानकारी के आधार पर जितना संभव हो सके।</p>', 'christan,mission,center,largest,graduation,', 'ईसाई, मिशन, केंद्र, सबसे बड़ा, स्नातक,', 1, 1, 1, 1, '19-01-2023', 'January', NULL, NULL),
(6, 4, 4, 1, 1, 1, 'Touch Screen Display Market In-Depth Analysis during 2020-2027', '2020-2027 के दौरान टच स्क्रीन डिस्प्ले मार्केट का गहन विश्लेषण', 'Touch-Screen-Display-Market-In-Depth-Analysis-during-2020-2027', 'image/postimg/63c927cb5ee61.png', '<p>The touch screen is a significant source of an input and output device usually covered on the top of an electronic gadget of an information processing structure. Technological advancements, the subsequent shift of consumers towards the newest technology, increasingly adopting the touchscreen technology in order to enhance the user experience is driving the growth of the touch screen display market. Moreover, features such as high picture quality, lower power consumption, ease of accessibility, the innovation of sleek models, and growth in disposable incomes are the key aspects influencing the touch screen display market growth.</p><p><br></p><p>The research dives deep into the global share, size, and trends, as well as growth rate of the Touch Screen Display market to project its progress during the forecast period, i.e., 2021–2027. Most importantly, the report further identifies the past, present, and future trends that are expected to influence the development rate of the Touch Screen Display market. The research segments the market on the basis of product type, application, and region.</p><p><br></p><p>The Covid-19 (coronavirus) pandemic is impacting society and the overall economy across the world. The impact of this pandemic is growing day by day as well as affecting the supply chain. The COVID-19 crisis is creating uncertainty in the stock market, massive slowing of supply chain, falling business confidence, and increasing panic among the customer segments. The overall effect of the pandemic is impacting the production process of several industries including Electronics and Semiconductor, and many more. Trade barriers are further restraining the demand- supply outlook. As government of different regions have already announced total lockdown and temporarily shutdown of industries, the overall production process being adversely affected; thus, hinder the overall Touch Screen Display market globally. This report on ‘Touch Screen Display market’ provides the analysis on impact on Covid-19 on various business segments and country markets. The report also showcase market trends and forecast to 2027, factoring the impact of Covid -19 Situation.</p><p><br></p><p>Increasing the use of electronic devices such as smartphones, tablets, laptops, smartwatch, and other wearable devices is the significant factor driving the growth of the touch screen display market. However, the increasing prices of raw materials utilized for the production of touch screen displays are the key hindering factor for the growth of the touch screen display market. Furthermore, the increasing trend of using multiple touch displays and scratch less display provide a lucrative opportunity for the market player of the touch screen display market. Rising demand for the touch screen display for kiosk, ATMs, vehicle display, healthcare devices, and others are expected to boom the growth of the touch screen display market.</p>', '<p>टच स्क्रीन एक इनपुट और आउटपुट डिवाइस का एक महत्वपूर्ण स्रोत है जो आमतौर पर सूचना प्रसंस्करण संरचना के इलेक्ट्रॉनिक गैजेट के शीर्ष पर कवर होता है। तकनीकी प्रगति, नवीनतम तकनीक की ओर उपभोक्ताओं का बाद का बदलाव, उपयोगकर्ता अनुभव को बढ़ाने के लिए टचस्क्रीन तकनीक को तेजी से अपनाना टच स्क्रीन डिस्प्ले मार्केट के विकास को चला रहा है। इसके अलावा, उच्च तस्वीर की गुणवत्ता, कम बिजली की खपत, पहुंच में आसानी, चिकना मॉडल का नवाचार, और डिस्पोजेबल आय में वृद्धि जैसी विशेषताएं टच स्क्रीन डिस्प्ले बाजार के विकास को प्रभावित करने वाले प्रमुख पहलू हैं।</p><p><br></p><p>अनुसंधान वैश्विक हिस्सेदारी, आकार और रुझानों के साथ-साथ टच स्क्रीन डिस्प्ले मार्केट की विकास दर में पूर्वानुमान अवधि, यानी 2021–2027 के दौरान अपनी प्रगति को प्रोजेक्ट करने के लिए गहरा गोता लगाता है। सबसे महत्वपूर्ण बात यह है कि रिपोर्ट अतीत, वर्तमान और भविष्य के रुझानों की पहचान करती है जो कि टच स्क्रीन डिस्प्ले बाजार की विकास दर को प्रभावित करने की उम्मीद है। अनुसंधान उत्पाद प्रकार, अनुप्रयोग और क्षेत्र के आधार पर बाजार को खंडित करता है।</p><p><br></p><p>कोविड-19 (कोरोनावायरस) महामारी दुनिया भर में समाज और समग्र अर्थव्यवस्था को प्रभावित कर रही है। इस महामारी का प्रभाव दिन-ब-दिन बढ़ता ही जा रहा है साथ ही सप्लाई चेन पर भी असर पड़ रहा है। COVID-19 संकट शेयर बाजार में अनिश्चितता पैदा कर रहा है, आपूर्ति श्रृंखला की भारी मंदी, व्यापार का विश्वास गिर रहा है, और ग्राहक वर्ग में घबराहट बढ़ रही है। महामारी का समग्र प्रभाव इलेक्ट्रॉनिक्स और सेमीकंडक्टर सहित कई उद्योगों की उत्पादन प्रक्रिया को प्रभावित कर रहा है, और बहुत कुछ। व्यापार बाधाएं मांग-आपूर्ति दृष्टिकोण को और बाधित कर रही हैं। जैसा कि विभिन्न क्षेत्रों की सरकार ने पहले ही पूर्ण लॉकडाउन और उद्योगों को अस्थायी रूप से बंद करने की घोषणा की है, समग्र उत्पादन प्रक्रिया पर प्रतिकूल प्रभाव पड़ रहा है; इस प्रकार, वैश्विक स्तर पर समग्र टच स्क्रीन डिस्प्ले बाजार में बाधा डालती है। \'टच स्क्रीन डिस्प्ले मार्केट\' पर यह रिपोर्ट विभिन्न व्यावसायिक क्षेत्रों और देश के बाजारों पर कोविड-19 के प्रभाव का विश्लेषण प्रदान करती है। रिपोर्ट में कोविड-19 स्थिति के प्रभाव को ध्यान में रखते हुए बाजार के रुझान और 2027 तक के पूर्वानुमान को भी प्रदर्शित किया गया है।</p><p><br></p><p>स्मार्टफोन, टैबलेट, लैपटॉप, स्मार्टवॉच और अन्य पहनने योग्य उपकरणों जैसे इलेक्ट्रॉनिक उपकरणों का उपयोग बढ़ाना टच स्क्रीन डिस्प्ले मार्केट के विकास को चलाने वाला महत्वपूर्ण कारक है। हालांकि, टच स्क्रीन डिस्प्ले के उत्पादन के लिए उपयोग किए जाने वाले कच्चे माल की बढ़ती कीमतें टच स्क्रीन डिस्प्ले मार्केट के विकास के लिए प्रमुख बाधा कारक हैं। इसके अलावा, कई टच डिस्प्ले और स्क्रैच लेस डिस्प्ले का उपयोग करने की बढ़ती प्रवृत्ति टच स्क्रीन डिस्प्ले मार्केट के मार्केट प्लेयर के लिए एक आकर्षक अवसर प्रदान करती है। कियोस्क, एटीएम, वाहन डिस्प्ले, हेल्थकेयर डिवाइस और अन्य के लिए टच स्क्रीन डिस्प्ले की बढ़ती मांग से टच स्क्रीन डिस्प्ले मार्केट के विकास में तेजी आने की उम्मीद है।</p>', 'screen,movie,display,market', 'स्क्रीन, फिल्म, प्रदर्शन, बाजार', NULL, 1, NULL, NULL, '19-01-2023', 'January', NULL, NULL),
(7, 2, 2, 1, 1, 1, 'Jaipur Range IG Umesh Dutta instructed police officers to prevent crime in Kotputli', 'जयपुर रेंज आईजी उमेश दत्ता ने कोटपूतली में पुलिस अधिकारियों को क्राइम की रोकथाम के दिए निर्देश', 'Jaipur-Range-IG-Umesh-Dutta-instructed-police-officers-to-prevent-crime-in-Kotputli', 'image/postimg/63e37ce36dada.jpg', '<p>Jaipur Range IG Umesh Dutta was on Kotputli tour today. Data took a meeting of top police officers of Jaipur Rural, Alwar, Sikar and Jhunjhunu regarding prevention of crime in Kotputli ASP office. Dutta instructed the officers to stop the increasing crimes in the state.</p><p><br></p><p><br></p><p><br></p><p><br></p><p>The matter of Vikas Prajapat\'s death also came up before the IG.</p><p><br></p><p>On the question raised about the shortage of personnel and staff less than the IG, the IG said that whatever resources and staff the police have and who work in the same, that is called the quality of the police. The same said about the ongoing 27-day dharna in Kotputli regarding the case of Vikas Prajapat\'s death. Police is working seriously on this. The matter here is very complicated. On which a thorough investigation is being done. Nothing more will be said in this matter right now. He left for Jaipur directly after the IG meeting.</p><p><br></p><p>Let us tell you that the Rajasthan Police has released the report today itself, in which it has been told that in Rajasthan, crimes have increased by more than 11 percent in a year. Increasing crime and cybercrime in Rajasthan remains a challenge for the police. The police is making every possible effort to nab the criminals. The police claim that soon the crime graph will come down.</p>', '<h2 style=\"margin-bottom: 10px; line-height: normal; padding-bottom: 5px; position: relative; padding-top: 0px;\"><font face=\"Mukta, sans-serif\"><span style=\"font-size: 18px;\">जयपुर रेंज आई जी उमेश दत्ता आज कोटपूतली दौरे पर रहे. दता ने कोटपूतली ASP कार्यलाय में क्राइम की रोकथाम को लेकर जयपुर ग्रामीण अलवर सीकर व झुंझुनू के पुलिस के आला अधिकारियों की बैठक ली. दत्ता ने अधिकारियों से प्रदेश में बढ़ रहे अपराधों को रोकने के निर्देश दिए.</span></font></h2><h2 style=\"margin-bottom: 10px; line-height: normal; padding-bottom: 5px; position: relative; padding-top: 0px;\"><font face=\"Mukta, sans-serif\"><span style=\"font-size: 18px;\"><br></span></font></h2><h2 style=\"margin-bottom: 10px; line-height: normal; padding-bottom: 5px; position: relative; padding-top: 0px;\"><font face=\"Mukta, sans-serif\"><span style=\"font-size: 18px;\"><br></span></font></h2><h2 style=\"margin-bottom: 10px; line-height: normal; padding-bottom: 5px; position: relative; padding-top: 0px;\"><font face=\"Mukta, sans-serif\"><span style=\"font-size: 18px;\"><br></span></font></h2><h2 style=\"margin-bottom: 10px; line-height: normal; padding-bottom: 5px; position: relative; padding-top: 0px;\"><font face=\"Mukta, sans-serif\"><span style=\"font-size: 18px;\"><br></span></font></h2><h2 style=\"margin-bottom: 10px; line-height: normal; padding-bottom: 5px; position: relative; padding-top: 0px;\"><font face=\"Mukta, sans-serif\"><span style=\"font-size: 18px;\">विकास प्रजापत की मौत का मामला भी आईजी के सामने उठा</span></font></h2><h2 style=\"margin-bottom: 10px; line-height: normal; padding-bottom: 5px; position: relative; padding-top: 0px;\"><font face=\"Mukta, sans-serif\"><span style=\"font-size: 18px;\"><br></span></font></h2><h2 style=\"margin-bottom: 10px; line-height: normal; padding-bottom: 5px; position: relative; padding-top: 0px;\"><font face=\"Mukta, sans-serif\"><span style=\"font-size: 18px;\">वही आई जी से कम नफरी व स्टाफ की कमी को लेकर किये गए सवाल पर आई जी ने कहा पुलिस के पास जो भी संसधान व स्टाफ व उसी में काम करे वो ही पुलिस को खूबी कहलाती है. वही कोटपूतली में चल रहे 27 दिन से विकास प्रजापत मौत के मामले धरने को लेकर कहा. पुलिस इस पर गंभीरता से काम कर रही है. यहां मामला बहुत जटिल है. जिस पर गहनता से जांच की जा रही है. अभी इस मामले में इससे ज्यादा कुछ भी कहना नहीं होगा. वही आई जी मीटिंग के बाद सीधे जयपुर रवाना हो गए.</span></font></h2><h2 style=\"margin-bottom: 10px; line-height: normal; padding-bottom: 5px; position: relative; padding-top: 0px;\"><font face=\"Mukta, sans-serif\"><span style=\"font-size: 18px;\"><br></span></font></h2><h2 style=\"margin-bottom: 10px; line-height: normal; padding-bottom: 5px; position: relative; padding-top: 0px;\"><font face=\"Mukta, sans-serif\"><span style=\"font-size: 18px;\">बता दें कि राजस्थान पुलिस ने आज ही रिपोर्ट जारी किया है, इसमें बताया गया है कि राजस्थान में एक साल में 11 फीसदी से ज्यादा अपराध बढ़े हैं. राजस्थान में बढ़ रहे अपराध और साइबर क्राइम पुलिस के लिए चुनौती बनी हुई है. पुलिस अपराधियों को पकड़ने की हर संभव कोशिश में है. पुलिस का दावा है कि जल्द ही अपराध का ग्राफ नीचे आएगा.&nbsp;</span></font></h2>', 'kotputli,ktp,kotputlinews,kotputli news, jaipur', 'kotputli,ktp,kotputlinews,kotputli news, jaipur', 1, 1, 1, NULL, '08-02-2023', 'February', NULL, NULL);
INSERT INTO `posts` (`id`, `category_id`, `subcategory_id`, `district_id`, `subdistrict_id`, `user_id`, `title_en`, `title_bg`, `slug`, `image`, `details_en`, `details_bg`, `tags_en`, `tags_bg`, `headline`, `first_section`, `first_section_thumbnail`, `bigthumbnail`, `post_date`, `post_month`, `created_at`, `updated_at`) VALUES
(8, 2, 2, 1, 1, 1, 'Day-long traffic jam on the highway due to President\'s program', 'राष्ट्रपति के कार्यक्रम के चलते राजमार्ग पर लगा रहा दिन भर जाम', 'Day-long-traffic-jam-on-the-highway-due-to-President\'s-program', 'image/postimg/63e670eb756c7.png', '<p>Vehicles diverted from Paniyala turn</p><p><br></p><p>Kotputli, 09 February 2023</p><p><br></p><p>The Jaipur-Delhi National Highway remained jammed throughout the day due to the President\'s program in Gurgaon, Haryana. It is worth mentioning that President Draupadi Murmu had a program in Pataudi which comes under Gurugram in Haryana. Due to which heavy vehicles were diverted by the police from Paniala turn itself. Due to this, there was a jam of about 5 km on the highway in the town. Due to which the common man had to face a lot of trouble. After 2 pm, the condition of the jam became normal when no entry opened.</p>', '<p><font color=\"#050505\" face=\"Segoe UI Historic, Segoe UI, Helvetica, Arial, sans-serif\"><span style=\"font-size: 15px;\">पनियाला मोड़ से करवाया गया वाहनों को डाईवर्ट</span></font></p><p><font color=\"#050505\" face=\"Segoe UI Historic, Segoe UI, Helvetica, Arial, sans-serif\"><span style=\"font-size: 15px;\"><br></span></font></p><p><font color=\"#050505\" face=\"Segoe UI Historic, Segoe UI, Helvetica, Arial, sans-serif\"><span style=\"font-size: 15px;\">कोटपूतली, 09 फरवरी 2023</span></font></p><p><font color=\"#050505\" face=\"Segoe UI Historic, Segoe UI, Helvetica, Arial, sans-serif\"><span style=\"font-size: 15px;\"><br></span></font></p><p><font color=\"#050505\" face=\"Segoe UI Historic, Segoe UI, Helvetica, Arial, sans-serif\"><span style=\"font-size: 15px;\">हरियाणा के गुरूग्राम में गुरूवार को राष्ट्रपति के कार्यक्रम के चलते जयपुर-दिल्ली राष्ट्रीय राजमार्ग पर दिन भर जाम लगा रहा। उल्लेखनीय है कि राष्ट्रपति द्रौपदी मूर्मू का हरियाणा के गुरूग्राम के अन्तर्गत आने वाले पटौदी में कार्यक्रम था। जिसके चलते पुलिस द्वारा पनियाला मोड़ से ही भारी वाहनों को डाईवर्ट किया गया। इसके चलते कस्बे में राजमार्ग पर लगभग 5 किमी लम्बा जाम लग गया। जिससे आमजन को भारी परेशानी का सामना करना पड़ा। दोपहर 2 बजे के बाद नो एन्ट्री खुलने पर जाम की स्थिति सामान्य हुई।</span></font></p>', 'ktp,kotputli,jaipur', 'ktp,kotputli', 1, 1, NULL, 1, '10-02-2023', 'February', NULL, NULL),
(9, 1, 1, 1, 1, 1, 'Inauguration of seven day open air, social useful production camp', 'सात दिवसीय ओपन एयर, समाज उपयोगी उत्पादन शिविर का शुभारम्भ', 'Inauguration-of-seven-day-open-air,-social-useful-production-camp', 'image/postimg/63e6716179d70.png', '<p>Kotputli, 08 February 2023</p><p><br></p><p>A seven-day open air, socially useful production camp was inaugurated by the students on Wednesday under the aegis of Shri Krishna Group of Education. Public awareness rally towards water conservation was taken out in the camp. A musical chair and song recognition competition was also organized there. Students actively participated in the competition. The chairman of the organization Ramsingh Yadav told the students about the importance of water. He flagged off the rally. The rally started from the college campus and was taken out through various routes. Students carrying placards with slogans in their hands gave the message of save electricity, save water to the arsonists through the slogan of water conservation. Executive Director Devesh Yadav gave the message of water conservation to the students through a rally. Principal Dr. Balwan Singh administered the oath to the students. During this, lecturers Rajveer Singh Yadav, Santosh, Kishan Singh Shekhawat, Nisha Chowdhary, Naresh Jangid, Ajay Sharma etc were present.</p>', '<p>कोटपूतली, 08 फरवरी 2023</p><p><br></p><p>श्री कृष्ण गु्रप ऑफ एज्यूकेशन के तत्वाधान में विधार्थियों द्वारा बुधवार को सात दिवसीय ओपन एयर, समाज उपयोगी उत्पादन शिविर का शुभारम्भ किया गया। शिविर में जल संरक्षण के प्रति जन जागरूकता रैली निकाली गई। वहीं म्यूजिकल चेयर व गाना पहचान प्रतियोगिता का आयोजन भी किया गया। प्रतियोगिता में विधार्थियों ने बढ़-चढकऱ भाग लिया। संस्था के चैयरमैन रामसिंह यादव ने छात्रों को जल के महत्व के बारे में बताया। उन्होंने रैली को हरी झण्डी दिखाकर रवाना किया। रैली कॉलेज परिसर से प्रारम्भ होकर विभिन्न मार्गो से निकाली गई। छात्रों ने हाथों में नारे लिखी तख्तियां लेकर जल संरक्षण के स्लोगन के माध्यम से आगजन को बिजली बचाओ, पानी बचाओ का संदेश दिया। कार्यकारी निदेशक देवेश यादव ने छात्रों को रैली के माध्यम से जल संरक्षण का संदेश दिया। प्राचार्य डॉ. बलवान सिंह ने छात्रों को शपथ दिलाई। इस दौरान व्याख्याता राजवीर सिंह यादव, संतोष, किशन सिंह शेखावत, निशा चौधरी, नरेश जांगिड़, अजय शर्मा आदि मौजूद रहे।</p>', NULL, NULL, 1, 1, 1, 1, '10-02-2023', 'February', NULL, NULL),
(10, 5, 5, 1, 1, 1, 'Junior bid farewell to senior students', 'जुनियर ने सीनियर विधार्थियों को दी विदाई', 'Junior-bid-farewell-to-senior-students', 'image/postimg/63e671e514648.png', '<p>Kotputli, 08 February 2023</p><p><br></p><p>A farewell function was organized for the students of class 12 on Wednesday at Delhi Public World School, located near Paniala Mod. In which the students of class 11th bid farewell to their seniors. Principal Bindu Sharma inaugurated the program by lighting the lamp and offering flowers in front of the idol of Maa Saraswati. Saraswati Vandana was presented by the class 11 students. The Principal while addressing the class 12 students said that this moment is very emotional. When we have to send off the students of our school. who have spent a long time with us. But at the same time, we are also happy that they will cross each step and travel further to the college for their bright future and progress. The students also presented ramp walk, dance and music. Children were honored on this occasion. Class 12th students shared their sweet and sour experiences of their student life while studying in the school. The students said that the knowledge and behavior that we got in this school through the best teachers to walk on the path of life, will be remembered as a guide throughout our life.</p>', '<p>कोटपूतली, 08 फरवरी 2023</p><p><br></p><p>निकटवर्ती पनियाला मोड़ स्थित दिल्ली पब्लिक वल्र्ड स्कूल में बुधवार को कक्षा 12 के छात्र-छात्राओं के लिए विदाई समारोह का आयोजन किया गया। जिसमें कक्षा 11 वीं के छात्र छात्राओं ने अपने सीनियर्स को विदाई दी। प्रधानाचार्य बिंदु शर्मा ने मां सरस्वती की प्रतिमा के समक्ष दीप प्रज्वलित एवं पुष्प अर्पित कर कार्यक्रम का शुभारंभ किया। कक्षा 11 की छात्राओं ने सरस्वती वंदना की प्रस्तुति दी। प्रधानाचार्य ने कक्षा 12 के छात्र छात्राओं को संबोधित करते हुए कहा कि यह पल बहुत भावुक करने वाला होता है। जब हमें अपने विद्यालय के छात्रों को विदा करना होता है। जिन्होंने एक लंबा समय हमारे साथ बिताया होता है। लेकिन साथ ही हमें खुशी भी होती है कि वे एक-एक पायदान पार करते हुए आगे अपने उज्जवल भविष्य और उन्नति के लिए महाविद्यालय का सफर तय करेंगे। छात्र-छात्राओं ने रैंप वॉक, नृत्य और संगीत की भी प्रस्तुति दी। इस अवसर पर बच्चों का सम्मान किया गया। 12 वीं के छात्रों ने विद्यालय में पढ़ते हुए अपने विद्यार्थी जीवन के खट्टे मीठे अनुभवों को साझा किया। छात्रों ने कहा कि इस विद्यालय में श्रेष्ठ शिक्षकों के द्वारा जीवन के पथ पर चलने का ज्ञान और व्यवहार जो मिला, वो हमें जीवन पर्यंत मार्गदर्शक के रुप में याद रहेगा।</p>', 'ktp,kotputli', NULL, 1, 1, 1, 1, '10-02-2023', 'February', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `seos`
--

CREATE TABLE `seos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `meta_author` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_keyword` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_analytics` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_verification` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alexa_analytics` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `seos`
--

INSERT INTO `seos` (`id`, `meta_author`, `meta_title`, `meta_keyword`, `meta_description`, `google_analytics`, `google_verification`, `alexa_analytics`, `created_at`, `updated_at`) VALUES
(1, 'kotputli news', 'kotputli news', 'kotputli news', 'kotputli news live today', 'kotputli news live', 'kotputli news live', 'kotputli news live', '2023-01-19 09:31:08', '2023-01-19 09:31:08');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('EgDjZi3zbBXmukPiHRSBEDkBdV7y3Cs32FLJeAd7', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36', 'YTo2OntzOjM6InVybCI7YTowOnt9czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NjoiX3Rva2VuIjtzOjQwOiJiQlM4ZjNuSGpOeUdnaGdXVkNkcmMyR3BIUEkwNjFWSTFDNmdFUjBhIjtzOjE3OiJwYXNzd29yZF9oYXNoX3dlYiI7czo2MDoiJDJ5JDEwJHUvN3MxZTJISDMvaThMdmwvclBUa2Vtamp1a01vOEJNeUtFOTZwQVFEenN6ZzY2Mi82RHhDIjtzOjIxOiJwYXNzd29yZF9oYXNoX3NhbmN0dW0iO3M6NjA6IiQyeSQxMCR1LzdzMWUySEgzL2k4THZsL3JQVGtlbWpqdWtNbzhCTXlLRTk2cEFRRHpzemc2NjIvNkR4QyI7fQ==', 1679821759);

-- --------------------------------------------------------

--
-- Table structure for table `socials`
--

CREATE TABLE `socials` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `facebook` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `linkedin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instagram` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `socials`
--

INSERT INTO `socials` (`id`, `facebook`, `twitter`, `youtube`, `linkedin`, `instagram`, `created_at`, `updated_at`) VALUES
(1, 'https://www.facebook.com/', 'https://twitter.com/', 'https://youtube.com/', 'https://www.linkedin.com/', 'https://www.instagram.com/', '2023-01-19 09:27:52', '2023-01-19 09:27:52');

-- --------------------------------------------------------

--
-- Table structure for table `subcategories`
--

CREATE TABLE `subcategories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subcategory_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subcategory_bg` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subcategories`
--

INSERT INTO `subcategories` (`id`, `category_id`, `subcategory_en`, `subcategory_bg`, `created_at`, `updated_at`) VALUES
(1, '1', 'University', 'विश्वविद्यालय', NULL, NULL),
(2, '2', 'Kotputli Politics', 'कोटपूतली राजनीति', NULL, NULL),
(3, '3', 'Accounting', 'लेखांकन', NULL, NULL),
(4, '4', 'Movies', 'चलचित्र', NULL, NULL),
(5, '5', 'Current Affairs/Features', 'करंट अफेयर्स / सुविधाएँ', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subdistricts`
--

CREATE TABLE `subdistricts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `district_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subdistrict_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subdistrict_bg` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subdistricts`
--

INSERT INTO `subdistricts` (`id`, `district_id`, `subdistrict_en`, `subdistrict_bg`, `created_at`, `updated_at`) VALUES
(1, '1', 'Kotputli', 'कोटपुतली', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(15) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `category` int(11) DEFAULT NULL,
  `district` int(11) DEFAULT NULL,
  `post` int(11) DEFAULT NULL,
  `setting` int(11) DEFAULT NULL,
  `website` int(11) DEFAULT NULL,
  `gallery` int(11) DEFAULT NULL,
  `ads` int(11) DEFAULT NULL,
  `role` int(11) DEFAULT NULL,
  `current_team_id` bigint(20) UNSIGNED DEFAULT NULL,
  `profile_photo_path` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `mobile`, `address`, `image`, `gender`, `position`, `two_factor_secret`, `two_factor_recovery_codes`, `remember_token`, `type`, `category`, `district`, `post`, `setting`, `website`, `gallery`, `ads`, `role`, `current_team_id`, `profile_photo_path`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin@kotputlinews.online', NULL, '$2y$10$oZUGyYdAf4Z4V2fP.OKSbOs5ZekDVOh3Vc4UR0ir3ARsciSXdBByi', '9694378957', 'Kotputli,Jaipur,303108.', '202301190914Profile.jpg', 'Male', 'CEO', NULL, NULL, '4YluRZN7BgIfRrNBLzFfP4k0mkB4fYvifYEX7DaRHQ0u2yNu4DjRVAmzNQm3', 1, 1, 1, 1, 1, 1, 1, 1, 1, NULL, NULL, '2021-04-20 11:31:50', '2023-03-26 03:22:00'),
(2, 'User', 'user@kotputlinews.online', NULL, '$2y$10$u/7s1e2HH3/i8Lvl/rPTkemjjukMo8BMyKE96pAQDzszg662/6DxC', '8949095100', 'address', '202303260857Profile.jpg', 'Male', 'Writer', NULL, NULL, NULL, 0, NULL, 1, 1, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, '2023-03-26 03:27:50');

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE `videos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `embed_code` varchar(525) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `videos`
--

INSERT INTO `videos` (`id`, `title`, `embed_code`, `type`, `created_at`, `updated_at`) VALUES
(1, 'O Sajna Ve Song', 'XxwlVZn--JQ', '1', '2023-01-19 12:52:59', '2023-01-19 12:52:59'),
(2, 'Desi Gangster Song', '2-8t-o4I3bY', '0', '2023-01-19 12:53:13', '2023-01-19 12:53:13');

-- --------------------------------------------------------

--
-- Table structure for table `websites`
--

CREATE TABLE `websites` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `website_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `websites`
--

INSERT INTO `websites` (`id`, `website_name`, `website_link`, `created_at`, `updated_at`) VALUES
(1, 'Desi Ka Dum', 'https://youtube.com/c/DesiKaDum', '2023-01-19 09:36:35', '2023-01-19 09:36:35');

-- --------------------------------------------------------

--
-- Table structure for table `websitesettings`
--

CREATE TABLE `websitesettings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_bg` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `websitesettings`
--

INSERT INTO `websitesettings` (`id`, `logo`, `address`, `phone_en`, `phone_bg`, `email`, `created_at`, `updated_at`) VALUES
(1, 'image/logo/60d2f7d04c773.png', 'Kotputli,Jaipur,Rajasthan', '9694378957', '9694378957', 'kotputlinewslive@gmail.com', '2023-01-19 09:39:26', '2023-01-19 09:39:26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ads`
--
ALTER TABLE `ads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `districts`
--
ALTER TABLE `districts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `livetvs`
--
ALTER TABLE `livetvs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notices`
--
ALTER TABLE `notices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `photos`
--
ALTER TABLE `photos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seos`
--
ALTER TABLE `seos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `socials`
--
ALTER TABLE `socials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subcategories`
--
ALTER TABLE `subcategories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subdistricts`
--
ALTER TABLE `subdistricts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `websites`
--
ALTER TABLE `websites`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `websitesettings`
--
ALTER TABLE `websitesettings`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ads`
--
ALTER TABLE `ads`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `districts`
--
ALTER TABLE `districts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `livetvs`
--
ALTER TABLE `livetvs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `notices`
--
ALTER TABLE `notices`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `photos`
--
ALTER TABLE `photos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `seos`
--
ALTER TABLE `seos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `socials`
--
ALTER TABLE `socials`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `subcategories`
--
ALTER TABLE `subcategories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `subdistricts`
--
ALTER TABLE `subdistricts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `videos`
--
ALTER TABLE `videos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `websites`
--
ALTER TABLE `websites`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `websitesettings`
--
ALTER TABLE `websitesettings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
